import { createApp } from 'vue'
import App from './App.vue'
require('@/assets/css/styles.css');

createApp(App).mount('#app')
